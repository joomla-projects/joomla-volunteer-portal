<?php
/**
 * Joomla.org site template
 *
 * @copyright   Copyright (C) 2005 - 2023 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;

/** @var \Joomla\CMS\Document\HtmlDocument $this */

// Declare the template as HTML5
$this->setHtml5(true);

HTMLHelper::_('stylesheet', 'system/joomla-fontawesome.min.css', ['version' => 'auto', 'relative' => true, 'detectDebug' => false], []);

if ($this->direction === 'ltr')
{
    if (JDEBUG || !$this->params->get('useCdn', '1'))
    {
        HTMLHelper::_('stylesheet', 'template.min.css', ['relative' => true, 'detectDebug' => (bool) JDEBUG, 'version' => '4.0.1']);
    }
    else
    {
        $this->addStyleSheet('https://cdn.joomla.org/template/css/template_4.0.1.min.css');
    }

    // Optional site specific CSS override
    HTMLHelper::_('stylesheet', 'custom.css', ['version' => 'auto', 'relative' => true, 'detectDebug' => false], []);
}
else
{
    if (JDEBUG || !$this->params->get('useCdn', '1'))
    {
        HTMLHelper::_('stylesheet', 'template-rtl.min.css', ['relative' => true, 'detectDebug' => (bool) JDEBUG, 'version' => '4.0.1']);
    }
    else
    {
        $this->addStyleSheet('https://cdn.joomla.org/template/css/template-rtl_4.0.1.min.css');
    }

    // Optional support for custom RTL CSS rules
    HTMLHelper::_('stylesheet', 'custom-rtl.css', ['version' => 'auto', 'relative' => true, 'detectDebug' => false], []);
}

// Load Google Font
$this->addHeadLink('https://fonts.googleapis.com/css?family=Open+Sans&display=swap', 'preload', 'rel', ['as' => 'style']);

// Set template metadata
$this->setMetaData('viewport', 'width=device-width, initial-scale=1.0');
?>
<!DOCTYPE html>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
	<jdoc:include type="head" />
</head>
<body class="contentpane modal">
	<jdoc:include type="message" />
	<jdoc:include type="component" />
</body>
</html>
