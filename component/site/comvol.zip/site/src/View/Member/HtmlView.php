<?php
/**
 * @package    Joomla! Volunteers
 * @copyright  Copyright (C) 2016 Open Source Matters, Inc. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Component\Volunteers\Site\View\Member;
// No direct access
defined('_JEXEC') or die;

use Exception;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

/**
 * View to edit a member.
 *
 * @since 4.0.0
 */
class HtmlView extends BaseHtmlView
{
	protected $state;

	protected $item;

	protected $form;

	protected $user;

	/**
	 * Execute and display a template script.
	 *
	 * @param   string $tpl The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  void
	 *
	 * @since 4.0.0
	 * @throws Exception
	 */
	public function display($tpl = null)
	{
		$this->state = $this->get('State');
		$this->item  = $this->get('Item');
		$this->form  = $this->get('Form');
		$this->user = Factory::getApplication()->getSession()->get('user');
		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new Exception(implode("\n", $errors),500);
		}

		// Manipulate form
		$this->_manipulateForm();

		// Prepare document
		$this->_prepareDocument();

		parent::display($tpl);
	}


	/**
	 * Prepares the document.
	 *
	 * @return  void.
	 * @since 4.0.0
	 */
	protected function _prepareDocument()
	{
		// Prepare variables
		$title = Text::_('COM_VOLUNTEERS_TITLE_MEMBERS_EDIT');

		// Set meta
		$this->document->setTitle($title);
	}


	/**
	 * Manipulates the form.
	 *
	 * @return  void.
	 * @since 4.0.0
	 * @throws Exception
	 */
	protected function _manipulateForm()
	{
		$app          = Factory::getApplication();
		$jinput       = $app->input;
		$memberId     = $jinput->getInt('id');
		$departmentId = (int) $app->getUserState('com_volunteers.edit.member.departmentid');
		$teamId       = (int) $app->getUserState('com_volunteers.edit.member.teamid');

		// Disable fields
		$this->form->setFieldAttribute('department', 'readonly', 'true');
		$this->form->setFieldAttribute('team', 'readonly', 'true');

		// Clear date ended field if not set
		if ($this->item->date_ended == '0000-00-00')
		{
			$this->form->setValue('date_ended', null, null);
		}

		// If editing existing member
		if ($memberId)
		{
			$this->form->setFieldAttribute('volunteer', 'readonly', 'true');
			$this->form->setFieldAttribute('position', 'readonly', 'true');

			if ($departmentId)
			{
				$this->form->removeField('role');
			}
		}
		else
		{
			$this->form->setValue('department', $department = null, $departmentId);
			$this->form->setValue('team', $team = null, $teamId);
			$this->form->setValue('date_started', $team = null, Factory::getDate());
			$this->item->department = $departmentId;
			$this->item->team       = $teamId;
		}
	}
}
