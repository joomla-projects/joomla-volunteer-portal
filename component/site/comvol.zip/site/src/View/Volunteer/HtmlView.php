<?php

/**
 * @package    Joomla! Volunteers
 * @copyright  Copyright (C) 2016 Open Source Matters, Inc. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */


namespace Joomla\Component\Volunteers\Site\View\Volunteer;
// No direct access
defined('_JEXEC') or die;

use Exception;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Volunteers\Site\Helper\VolunteersHelper;

/**
 * View class for a single volunteer.
 *
 * @since  4.0.0
 */
class HtmlView extends BaseHtmlView
{

	protected $state;

	protected $item;

	protected $form;

	protected $user;

	protected $share;

	/**
	 * Execute and display a template script.
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  void
	 * @throws Exception
	 * @since 4.0.0
	 */
	public function display($tpl = null)
	{

		$session = Factory::getApplication()->getSession();


		$this->item        = $this->get('Item');

		$this->state       = $this->get('State');
		$this->form        = $this->get('Form');
		$this->user        = $session->get('user');
		$this->item->teams = $this->get('VolunteerTeams');
		$this->item->new   = Factory::getApplication()->input->getInt('new', '0');

		// Set volunteer id in session
		$session->set('volunteer', $this->item->id);

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new Exception(implode("\n", $errors),500);
		}

		// Manipulate form
		$this->_manipulateForm();

		// Prepare document
		$this->_prepareDocument();

		parent::display($tpl);
	}

	/**
	 * Prepares the document.
	 *
	 * @return  void.
	 *
	 * @since 4.0.0
	 * @throws Exception
	 */
	protected function _prepareDocument()
	{
		// Prepare variables
		$title       = Text::_('COM_VOLUNTEERS_TITLE_VOLUNTEER') . ': ' . $this->item->name;
		$description = HtmlHelper::_('string.truncate', $this->item->intro, 160, true, false);
		$image       = VolunteersHelper::image($this->item->image, 'large', true);
		$itemURL     = Route::_('index.php?option=com_volunteers&view=volunteer&id=' . $this->item->id);
		$url         = Uri::getInstance()->toString(['scheme', 'host', 'port']) . $itemURL;

		// Set meta
		$this->document->setTitle($title);
		$this->document->setDescription($description);

		// Twitter Card metadata
		$this->document->setMetaData('twitter:title', $title);
		$this->document->setMetaData('twitter:description', $description);
		$this->document->setMetaData('twitter:image', $image);

		// OpenGraph metadata
		$this->document->setMetaData('og:title', $title, 'property');
		$this->document->setMetaData('og:description', $description, 'property');
		$this->document->setMetaData('og:image', $image, 'property');
		$this->document->setMetaData('og:type', 'article', 'property');
		$this->document->setMetaData('og:url', $url, 'property');

		// Add to pathway
		$pathway = Factory::getApplication()->getPathway();
		$pathway->addItem($this->item->name, $itemURL);
	}

	/**
	 * Manipulates the form.
	 *
	 * @return  void.
	 *
	 * @since 4.0.0
	 */
	protected function _manipulateForm()
	{
		// Clear birthday field if not set
		if ($this->item->birthday == '0000-00-00')
		{
			$this->form->setValue('birthday', null, null);
		}

		// Make mailing address required for active team members
		if($this->item->teams->activemember)
		{
			$this->form->setFieldAttribute('address', 'required', 'true');
			$this->form->setFieldAttribute('zip', 'required', 'true');
		}
	}
}
