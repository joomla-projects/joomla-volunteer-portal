<?php

/**
 * @version    4.0.0
 * @package    Com_Volunteers
 * @author     The Joomla Project <secretary@opensourcematters.org>
 * @copyright  2022 The Joomla Project
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Component\Volunteers\Site\View\My;
// No direct access
defined('_JEXEC') or die;

use Exception;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/**
 * View class for a list of Volunteers.
 *
 * @since  4.0.0
 */
class HtmlView extends BaseHtmlView
{


	/**
	 * Execute and display a template script.
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  void
	 *
	 * @throws Exception
	 *
	 * @since 4.0.0
	 */
	public function display($tpl = null)
	{
		$model = Factory::getApplication()->bootComponent('com_volunteers')->getMVCFactory()
			->createModel('Volunteer', 'Administrator', array('ignore_request' => true));
		$user        = Factory::getApplication()->getSession()->get('user');;
		$userId      = (int) $user->get('id');
		$volunteerId = (int) $model->getVolunteerId($userId);

		if ($volunteerId)
		{
			Factory::getApplication()->redirect(Route::_('index.php?option=com_volunteers&view=volunteer&id=' . $volunteerId, false));
		}
		parent::display($tpl);
	}


}
