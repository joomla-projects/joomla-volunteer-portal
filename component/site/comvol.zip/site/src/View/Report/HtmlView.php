<?php
/**
 * @package    Joomla! Volunteers
 * @copyright  Copyright (C) 2016 Open Source Matters, Inc. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Component\Volunteers\Site\View\Report;
// No direct access
defined('_JEXEC') or die;

use Exception;
use JLayoutFile;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\HTML\Helpers\StringHelper;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Volunteers\Site\Helper\VolunteersHelper;

/**
 * View to edit a report.
 *
 * @since 4.0.0
 */
class HtmlView extends BaseHtmlView
{
	protected $item;

	protected $state;

	protected $form;

	protected $user;
	
	protected $share;

	protected $acl;

	protected $volunteer;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template
	 *
	 * @return  void
	 *
	 * @since 4.0.0
	 * @throws Exception
	 */
	public function display($tpl = null)
	{
		$this->state = $this->get('State');
		$this->item  = $this->get('Item');

		$this->form  = $this->get('Form');
		$this->user          = Factory::getApplication()->getSession()->get('user');

		// Load volunteer data for new report
		if (!$this->item->id)
		{
			$this->volunteer = $this->get('Volunteer');
		}

		if ($this->item->department && ($this->item->department_parent_id == 0))
		{
			$this->acl        = VolunteersHelper::acl('department', $this->item->department);
			$this->item->link = Route::_('index.php?option=com_volunteers&view=board&id=' . $this->item->department);
			$this->item->name = $this->item->department_title;
		}
		elseif ($this->item->department)
		{
			$this->acl        = VolunteersHelper::acl('department', $this->item->department);
			$this->item->link = Route::_('index.php?option=com_volunteers&view=department&id=' . $this->item->department);
			$this->item->name = $this->item->department_title;
		}
		elseif ($this->item->team)
		{
			$this->acl        = VolunteersHelper::acl('team', $this->item->team);
			$this->item->link = Route::_('index.php?option=com_volunteers&view=team&id=' . $this->item->team);
			$this->item->name = $this->item->team_title;
		}

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new Exception(implode("\n", $errors),500);
		}

		// Manipulate form
		$this->_manipulateForm();

		// Prepare document
		$this->_prepareDocument();

		parent::display($tpl);
	}

	/**
	 * Prepares the document.
	 *
	 * @return  void.
	 * @throws Exception
	 *
	 * @since 4.0.0
	 */
	protected function _prepareDocument()
	{
		$layout = Factory::getApplication()->input->get('layout');

		if ($layout == 'edit')
		{
			// Prepare variables
			$title = Text::_('COM_VOLUNTEERS_TITLE_REPORTS_EDIT');

			// Set meta
			$this->document->setTitle($title);

			return;
		}

		// Prepare variables
		$typeTitle   = ($this->item->team) ? $this->item->team_title : $this->item->department_title;
		$title       = $this->item->title . ' - ' . $typeTitle;
		$description = StringHelper::truncate($this->item->description, 160, true, false);
		$itemURL     = Route::_('index.php?option=com_volunteers&view=report&id=' . $this->item->id);
		$url         = Uri::getInstance()->toString(['scheme', 'host', 'port']) . $itemURL;

		// Set meta
		$this->document->setTitle($title);
		$this->document->setDescription($description);

		// Twitter Card metadata
		$this->document->setMetaData('twitter:title', $title);
		$this->document->setMetaData('twitter:description', $description);
		$this->document->setMetaData('twitter:image', Uri::base() . 'images/reports-twitter.jpg');

		// OpenGraph metadata
		$this->document->setMetaData('og:title', $title, 'property');
		$this->document->setMetaData('og:description', $description, 'property');
		$this->document->setMetaData('og:image', Uri::base() . 'images/reports-og.jpg', 'property');
		$this->document->setMetaData('og:type', 'article', 'property');
		$this->document->setMetaData('og:url', $url, 'property');

		// Share Buttons
		$layout      = new JLayoutFile('joomlarrssb');
		$data        = (object) array(
			'title'            => $title,
			'image'            => Uri::base() . 'images/reports-og.jpg',
			'url'              => $url,
			'text'             => $description,
			'displayEmail'     => true,
			'displayFacebook'  => true,
			'displayTwitter'   => true,
			'displayGoogle'    => false,
			'displayLinkedin'  => true,
			'displayPinterest' => true,
			'shorten'          => true,
			'shortenKey'       => ComponentHelper::getParams('com_volunteers')->get('yourlsapikey')
		);
		$this->share = $layout->render($data);

		// Add to pathway
		$pathway = Factory::getApplication()->getPathway();
		if ($this->item->team)
		{
			$pathway->addItem($this->item->team_title, Route::_('index.php?option=com_volunteers&view=team&id=' . $this->item->team));
		}
		elseif ($this->item->department)
		{
			$pathway->addItem($this->item->department_title, Route::_('index.php?option=com_volunteers&view=department&id=' . $this->item->department));
		}
		$pathway->addItem($this->item->title, $itemURL);
	}

	/**
	 * Manipulates the form.
	 *
	 * @return  void.
	 * @throws Exception
	 * @since 4.0.0
	 */
	protected function _manipulateForm()
	{
		$app      = Factory::getApplication();
		$jinput   = $app->input;
		$reportId = $jinput->getInt('id');

		// Disable fields
		$this->form->setFieldAttribute('department', 'readonly', 'true');
		$this->form->setFieldAttribute('team', 'readonly', 'true');

		// If editing existing report
		if ($reportId)
		{
			//$this->form->setFieldAttribute('volunteer', 'readonly', 'true');
		}
		else
		{
			$departmentId = (int) $app->getUserState('com_volunteers.edit.report.departmentid');
			$teamId       = (int) $app->getUserState('com_volunteers.edit.report.teamid');
			$this->form->setValue('department', $department = null, $departmentId);
			$this->form->setValue('team', $team = null, $teamId);
			$this->form->setValue('created', $team = null, Factory::getDate());
			$this->item->department = $departmentId;
			$this->item->team       = $teamId;
		}
	}
}
