<?php
/**
 * @package    Joomla! Volunteers
 * @copyright  Copyright (C) 2016 Open Source Matters, Inc. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Component\Volunteers\Site\View\Role;
// No direct access
defined('_JEXEC') or die;

use Exception;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

/**
 * View to edit a role.
 *
 * @since 4.0.0
 */
class HtmlView extends BaseHtmlView
{
	protected $item;

	protected $state;

	protected $form;

	protected $user;

	/**
	 * Execute and display a template script.
	 *
	 * @param   string $tpl The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  void
	 *
	 * @since 4.0.0
	 * @throws Exception
	 */
	public function display($tpl = null)
	{
		$this->state = $this->get('State');
		$this->item  = $this->get('Item');
		$this->form  = $this->get('Form');
		$this->user          = Factory::getApplication()->getSession()->get('user');

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new Exception(implode("\n", $errors),500);

		}

		// Manipulate form
		$this->_manipulateForm();

		// Prepare document
		$this->_prepareDocument();

		parent::display($tpl);
	}

	/**
	 * Prepares the document.
	 *
	 * @return  void.
	 * @since 4.0.0
	 */
	protected function _prepareDocument()
	{
		// Prepare variables
		$title = Text::_('COM_VOLUNTEERS_TITLE_ROLES_EDIT');

		// Set meta
		$this->document->setTitle($title);
	}

	/**
	 * Manipulates the form.
	 *
	 * @return  void.
	 *
	 * @since 4.0.0
	 * @throws Exception
	 */
	protected function _manipulateForm()
	{
		$app      = Factory::getApplication();
		$jinput   = $app->input;
		$memberId = $jinput->getInt('id');
		$this->form->setFieldAttribute('team', 'readonly', 'true');

		// If editing existing member
		if (!$memberId)
		{
			$teamId = (int) $app->getUserState('com_volunteers.edit.role.teamid');
			$this->form->setValue('team', $team = null, $teamId);
			$this->item->team = $teamId;
		}
	}
}
