<?php
/**
 * @package    Joomla! Volunteers
 * @copyright  Copyright (C) 2016 Open Source Matters, Inc. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Component\Volunteers\Administrator\Controller;

// No direct access.
defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;

/**
 * Volunteer controller class.
 *
 * @since 4.0.0
 */
class VolunteerController extends FormController
{
	protected $view_list = 'volunteers';
}
