<?php
/**
 * @package    Joomla! Volunteers
 * @copyright  Copyright (C) 2016 Open Source Matters, Inc. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Component\Volunteers\Administrator\View\Volunteers;
// No direct access
defined('_JEXEC') or die;

use Exception;
use JHelperContent;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\Component\Volunteers\Administrator\Helper\VolunteersHelper;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\Helpers\Sidebar;
/**
 * View class for a list of volunteers.
 *
 * @since  4.0.0
 */
class HtmlView extends BaseHtmlView
{
	protected $items;

	protected $pagination;

	protected $state;

	public $filterForm;

	protected $activeFilters;
	/**
	 * @var string
	 * @since version
	 */
	private string $sidebar;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template name
	 *
	 * @return  void
	 *
	 * @throws Exception
	 *
	 * @since 4.0.0
	 */
	public function display($tpl = null)
	{
		$this->state         = $this->get('State');
		$this->items         = $this->get('Items');
		$this->pagination    = $this->get('Pagination');
		$this->filterForm    = $this->get('FilterForm');
		$this->activeFilters = $this->get('ActiveFilters');

		VolunteersHelper::addSubmenu('volunteers');

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new Exception(implode("\n", $errors));
		}

		$this->addToolbar();

		$this->sidebar = Sidebar::render();
		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return  void
	 *
	 * @since   4.0.0
	 * @throws Exception
	 */
	protected function addToolbar()
	{

		$state = $this->get('State');
		$canDo = JHelperContent::getActions('com_volunteers');
		$user  = Factory::getApplication()->getSession()->get('user');

		// Set toolbar title
		ToolbarHelper::title(Text::_('COM_VOLUNTEERS') . ': ' . Text::_('COM_VOLUNTEERS_TITLE_VOLUNTEERS'), 'joomla');

		if ($canDo->get('core.create'))
		{
			ToolbarHelper::addNew('volunteer.add');
		}

		if ($canDo->get('core.edit'))
		{
			ToolbarHelper::editList('volunteer.edit');
		}

		if ($canDo->get('core.edit.state'))
		{
			ToolbarHelper::publish('volunteers.publish', 'JTOOLBAR_PUBLISH', true);
			ToolbarHelper::unpublish('volunteers.unpublish', 'JTOOLBAR_UNPUBLISH', true);
			ToolbarHelper::archiveList('volunteers.archive');
			ToolbarHelper::checkin('volunteers.checkin');
		}

		if ($state->get('filter.state') == -2 && $canDo->get('core.delete'))
		{
			ToolbarHelper::deleteList('', 'volunteers.delete', 'JTOOLBAR_EMPTY_TRASH');
		}
		elseif ($canDo->get('core.edit.state'))
		{
			ToolbarHelper::trash('volunteers.trash');
		}

		if ($user->authorise('core.admin', 'com_volunteers') || $user->authorise('core.options', 'com_volunteers'))
		{
			ToolbarHelper::preferences('com_volunteers');
		}

		if ($canDo->get('core.edit'))
		{
			ToolbarHelper::custom('volunteers.resetspam', 'refresh', 'refresh2.png', 'COM_VOLUNTEERS_TOOLBAR_RESET', false);
		}
	}
}
