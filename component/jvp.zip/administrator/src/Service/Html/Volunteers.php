<?php

/**
 * @package    VOLUNTEERS_PORTAL
 *
 * @copyright  (C) 2022 Open Source Matters, Inc.  <https://www.joomla.org>
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace  Joomla\Component\Volunteers\Administrator\Service\Html;

defined('_JEXEC') or die;
use function defined;

/**
 * VOLUNTEERS_PORTAL HTML class.
 *
 * @since  4.0.0
 */
class Volunteers
{
}
